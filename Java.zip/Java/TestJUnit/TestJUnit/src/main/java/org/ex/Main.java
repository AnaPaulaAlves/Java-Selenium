package org.ex;

public class Main {
    public static void main(String[] args) {
    }
}