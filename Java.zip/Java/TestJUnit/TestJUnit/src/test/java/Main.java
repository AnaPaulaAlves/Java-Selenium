public class Main {
    public static void main(String[] args){
        InicialJUnit open = new InicialJUnit();
        InicialJUnit verificar = new InicialJUnit();

        open.OpenWeb();
        verificar.VerificarSubTitulo();

    }
}
